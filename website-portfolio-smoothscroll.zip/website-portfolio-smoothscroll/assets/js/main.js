document.addEventListener('DOMContentLoaded',()=>{
  document.getElementById('year').textContent=new Date().getFullYear();
  const form=document.getElementById('contactForm'); const status=document.getElementById('status');
  form.addEventListener('submit',e=>{e.preventDefault(); status.textContent='Sending...'; setTimeout(()=>{status.textContent='Message sent! (mock)'; form.reset();},1000);});
  const links=document.querySelectorAll('.nav-links a');
  window.addEventListener('scroll',()=>{
    let current=''; document.querySelectorAll('section').forEach(sec=>{
      const top=window.scrollY; const offset=sec.offsetTop-100; const height=sec.offsetHeight; if(top>=offset&&top<offset+height){current=sec.getAttribute('id');}
    });
    links.forEach(l=>{l.classList.remove('active'); if(l.getAttribute('href')==='#'+current){l.classList.add('active');}});
  });
});